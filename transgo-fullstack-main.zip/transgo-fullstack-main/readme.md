cd driver && npm start
cd user && npm start
cd event && npm start
cd match && npm start
cd nearest && npm start 
cd auth && npm start
cd location && npm start
cd frontend/client && npm start
cd frontend/admin && npm run dev
cd admin && npm start


git add .
git commit -m "feature complete"
git push origin 

npm start

transgo!