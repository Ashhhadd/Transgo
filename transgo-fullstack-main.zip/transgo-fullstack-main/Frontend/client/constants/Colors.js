const Colors = {
  primary: "#123b66",
  secondary: "#60c6c2",
  error: "#e74c3c",
  white: "#ffffff",
  black: "#000000",
  input: "#f0fcfc",
  lightgrey: "#f9f9f9",
  // ... add other colors as needed
  //#90adbc greyish color from logo
};

export default Colors;
