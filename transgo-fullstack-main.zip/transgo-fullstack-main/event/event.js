const eventConsumer = require("./eventConsumer")

eventConsumer();