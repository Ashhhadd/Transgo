const matchConsumer = require("./matchConsumer")
const responseConsumer = require("./responseConsumer")

matchConsumer();

responseConsumer();