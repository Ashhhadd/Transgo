npm start --prefix ./Auth > Auth.log 2>&1 &

npm start --prefix ./Frontend/client > frontend-clinet.log 2>&1 &

